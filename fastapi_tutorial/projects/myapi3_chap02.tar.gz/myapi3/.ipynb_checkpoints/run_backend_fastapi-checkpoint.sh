#!/bin/bash
/home/fastapi/.local/bin/uvicorn main:app --host 0.0.0.0 --port 38888 --reload

