#!/bin/bash
npm run dev --  --host 0.0.0.0

